using System;

namespace wl
{
	/// <summary>
	/// Summary description for TrustAllCertificatePolicy.
	/// </summary>
	public class TrustAllCertificatePolicy : System.Net.ICertificatePolicy
	{
		public TrustAllCertificatePolicy()
		{}

		public bool CheckValidationResult(System.Net.ServicePoint sp,
			System.Security.Cryptography.X509Certificates.X509Certificate cert, System.Net.WebRequest req, int problem)
		{
			return true;
		}
	}
}
